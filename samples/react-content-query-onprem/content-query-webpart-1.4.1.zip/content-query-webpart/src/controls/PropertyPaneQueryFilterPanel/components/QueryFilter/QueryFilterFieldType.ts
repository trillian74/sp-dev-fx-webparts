export enum QueryFilterFieldType {
	Text = 1,
	Number= 2,
    Datetime = 3,
	User = 4,
	Lookup = 5,
    Taxonomy = 6,
	Url = 7
}