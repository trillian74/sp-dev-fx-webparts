/* tslint:disable */
require('./QueryFilterPanel.module.css');
const styles = {
  queryFilterPanel: 'queryFilterPanel_9d1f06a4',
  queryFilterPanelItems: 'queryFilterPanelItems_9d1f06a4',
  queryFilterPanelItem: 'queryFilterPanelItem_9d1f06a4',
};

export default styles;
/* tslint:enable */