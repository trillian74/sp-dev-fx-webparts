/* tslint:disable */
require('./QueryFilter.module.css');
const styles = {
  queryFilter: 'queryFilter_f02595ab',
  disabled: 'disabled_f02595ab',
  paddingContainer: 'paddingContainer_f02595ab',
  peoplePicker: 'peoplePicker_f02595ab',
};

export default styles;
/* tslint:enable */