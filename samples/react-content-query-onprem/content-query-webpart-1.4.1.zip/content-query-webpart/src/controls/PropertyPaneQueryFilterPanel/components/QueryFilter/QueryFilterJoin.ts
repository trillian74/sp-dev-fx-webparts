export enum QueryFilterJoin {
    And = 1,
    Or = 2
}