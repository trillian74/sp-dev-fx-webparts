import { IQueryFilter } from './IQueryFilter';

export interface IQueryFilterState {
    filter: IQueryFilter;
    pickersKey: number;
}