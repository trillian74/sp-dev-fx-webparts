/* tslint:disable */
require('./AceEditor.module.css');
const styles = {
  ace_editor: 'ace_editor_fae75482',
  ace_autocomplete: 'ace_autocomplete_fae75482',
};

export default styles;
/* tslint:enable */