/* tslint:disable */
require('./TextDialog.module.css');
const styles = {
  textDialog: 'textDialog_a1cfc72d',
};

export default styles;
/* tslint:enable */