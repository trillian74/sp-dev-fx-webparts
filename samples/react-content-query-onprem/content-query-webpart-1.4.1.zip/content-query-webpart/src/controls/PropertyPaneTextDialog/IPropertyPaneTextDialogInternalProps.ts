import { IPropertyPaneCustomFieldProps }    from '@microsoft/sp-webpart-base';
import { IPropertyPaneTextDialogProps } 	from './IPropertyPaneTextDialogProps';

export interface IPropertyPaneTextDialogInternalProps extends IPropertyPaneTextDialogProps, IPropertyPaneCustomFieldProps {

}