/* tslint:disable */
require('./AsyncChecklist.module.css');
const styles = {
  checklist: 'checklist_2012e876',
  checklistItems: 'checklistItems_2012e876',
  checklistPadding: 'checklistPadding_2012e876',
  checklistItem: 'checklistItem_2012e876',
};

export default styles;
/* tslint:enable */