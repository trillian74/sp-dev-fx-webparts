export interface IAsyncChecklistStrings {
    label: string;
    loading: string;
    errorFormat: string;
}