export interface IChecklistItem {
    id: string;
    label: string;
}