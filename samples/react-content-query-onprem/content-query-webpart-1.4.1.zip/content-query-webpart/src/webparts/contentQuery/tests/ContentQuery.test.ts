/// <reference types="mocha" />

import { assert } from 'chai';

describe('ContentQueryWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
