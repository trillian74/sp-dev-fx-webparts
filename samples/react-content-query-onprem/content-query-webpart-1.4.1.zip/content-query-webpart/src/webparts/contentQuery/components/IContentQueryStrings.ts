export interface IContentQueryStrings {
	loadingItems: string;
	mandatoryProperties: string;
	errorLoadingQuery: string;
	errorLoadingTemplate: string;
	errorProcessingTemplate: string;
}