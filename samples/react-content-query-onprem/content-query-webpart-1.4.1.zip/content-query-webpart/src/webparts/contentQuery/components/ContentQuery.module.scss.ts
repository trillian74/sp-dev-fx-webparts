/* tslint:disable */
require('./ContentQuery.module.css');
const styles = {
  cqwp: 'cqwp_abfa2809',
  cqwpValidations: 'cqwpValidations_abfa2809',
  cqwpError: 'cqwpError_abfa2809',
};

export default styles;
/* tslint:enable */