export interface IContentQueryState {
	loading: boolean;
	processedTemplateResult: string;
	error: string;
}